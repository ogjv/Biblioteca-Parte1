package br.edu.femass.model;

import java.util.ArrayList;
import java.util.List;

public class Livro {
    private long codigo;
    private String titulo;
    private List<Exemplar> exemplares;
    private List<Autor> autores;

    public Livro(long codigo, String titulo){
        this.codigo=codigo;
        this.titulo=titulo;
        this.exemplares= new ArrayList<Exemplar>();
    }
    public void setCodigo(long codigo){

        this.codigo=codigo;
    }
    public void setTitulo(String titulo)
    {
        this.titulo=titulo;
    }
    public long getCodigo()
    {
        return codigo;

    }
    public String getTitulo()
    {
        return titulo;

    }
    public String getAutores(){
        String resp="";
        for (Autor autor: autores){
            resp+=autor.toString() + "/n";
        }
        return resp;
    }

    @Override
    public String toString() {
        return this.titulo;
    }

    @Override
    public boolean equals(Object obj) {
        Livro livro = (Livro) obj;
        return getTitulo().equals(this.titulo);
     }
}
