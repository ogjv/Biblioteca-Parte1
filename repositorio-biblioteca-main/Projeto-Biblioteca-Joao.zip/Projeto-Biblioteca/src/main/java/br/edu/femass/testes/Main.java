package br.edu.femass.testes;


import br.edu.femass.dao.DaoAutor;
import br.edu.femass.dao.DaoLivro;
import br.edu.femass.model.Autor;
import br.edu.femass.model.Livro;

public class Main {
    public static void main(String[] args) {
        Livro l1 = new Livro(1234L,"A volta dos que não foram");
        Autor a1 = new Autor("João victor", "Magalhães", "Brasileiro");
        DaoLivro dao = new DaoLivro();
        DaoAutor daoa = new DaoAutor();
        try {
            daoa.save(a1);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}