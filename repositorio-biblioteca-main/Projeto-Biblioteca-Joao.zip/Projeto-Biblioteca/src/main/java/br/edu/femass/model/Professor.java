package br.edu.femass.model;

import br.edu.femass.model.Leitor;

public class Professor extends Leitor {
    private String disciplina;
    public Professor(long codigoLeitor, String nome, String endereco, String telefone, Integer prazoMaximoDevolucao, String disciplina){
        super(codigoLeitor,nome,endereco,telefone,prazoMaximoDevolucao);
        this.disciplina=disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getDisciplina() {
        return disciplina;
    }

}
