package br.edu.femass.model;

public class Aluno extends Leitor {
    private String matricula;
    public Aluno(long codigoLeitor, String nome, String endereco, String telefone, Integer prazoMaximoDevolucao,String matricula){
        super(codigoLeitor,nome,endereco,telefone,prazoMaximoDevolucao);
        this.matricula=matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }
}
