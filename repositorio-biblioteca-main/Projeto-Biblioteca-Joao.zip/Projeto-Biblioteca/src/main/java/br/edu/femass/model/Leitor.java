package br.edu.femass.model;
import java.util.ArrayList;
import java.util.List;

public class Leitor {
    private long codigoLeitor;
    private String nome;
    private String endereco;
    private String telefone;
    private Integer prazoMaximoDevolucao;
    private List<Emprestimo> emprestimos;
    public Leitor(long codigoLeitor, String nome, String endereco, String telefone, Integer prazoMaximoDevolucao){
        this.codigoLeitor=codigoLeitor;
        this.nome=nome;
        this.endereco=endereco;
        this.telefone=telefone;
        this.prazoMaximoDevolucao=prazoMaximoDevolucao;
        this.emprestimos=new ArrayList<Emprestimo>();
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setCodigoLeitor(long codigoLeitor) {
        this.codigoLeitor = codigoLeitor;
    }

    public void setPrazoMaximoDevolucao(Integer prazoMaximoDevolucao) {
        this.prazoMaximoDevolucao = prazoMaximoDevolucao;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public Integer getPrazoMaximoDevolucao() {
        return prazoMaximoDevolucao;
    }

    public String getTelefone() {
        return telefone;
    }

    public long getCodigoLeitor() {
        return codigoLeitor;
    }

}
